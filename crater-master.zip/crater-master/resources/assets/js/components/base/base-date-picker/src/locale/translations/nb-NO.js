import Language from '../Language'

export default new Language(
  'Norwegian Bokmål',
  ['Januar', 'Februar', 'Mars', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Desember'],
  ['Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Des'],
  ['Sø', 'Ma', 'Ti', 'On', 'To', 'Fr', 'Lø']
)
// eslint-disable-next-line
;
