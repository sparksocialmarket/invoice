import Multiselect from './Multiselect'
import multiselectMixin from './multiselectMixin'
import pointerMixin from './pointerMixin'

export default Multiselect

export { Multiselect, multiselectMixin, pointerMixin }
