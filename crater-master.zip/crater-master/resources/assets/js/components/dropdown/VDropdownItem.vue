<template>
  <div class="dropdown-group-item">
    <slot/>
  </div>
</template>
