export const isAuthenticated = (state) => !!state.token
export const authStatus = (state) => state.status
