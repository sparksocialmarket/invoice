export const items = (state) => state.items
export const selectAllField = (state) => state.selectAllField
export const selectedItems = (state) => state.selectedItems
export const totalItems = (state) => state.totalItems
export const itemUnits = (state) => state.itemUnits
