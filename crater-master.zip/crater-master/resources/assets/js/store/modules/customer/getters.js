export const customers = (state) => state.customers
export const selectAllField = (state) => state.selectAllField
export const selectedCustomers = (state) => state.selectedCustomers
export const totalCustomers = (state) => state.totalCustomers
