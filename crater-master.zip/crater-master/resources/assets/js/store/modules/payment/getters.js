export const payments = (state) => state.payments
export const selectedPayments = (state) => state.selectedPayments
export const selectAllField = (state) => state.selectAllField
export const totalPayments = (state) => state.totalPayments
export const paymentModes = (state) => state.paymentModes
