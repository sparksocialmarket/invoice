export const getMomentDateFormat = (state) => state.momentDateFormat
