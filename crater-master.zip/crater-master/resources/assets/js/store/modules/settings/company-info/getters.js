export const company = (state) => state.company
