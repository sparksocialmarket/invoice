export const currentUser = (state) => state.currentUser
