export const expenses = (state) => state.expenses
export const selectAllField = (state) => state.selectAllField
export const selectedExpenses = (state) => state.selectedExpenses
export const totalExpenses = (state) => state.totalExpenses
