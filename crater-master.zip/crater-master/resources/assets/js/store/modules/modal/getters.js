export const modalActive = state => state.active
export const modalTitle = state => state.title
export const componentName = state => state.componentName
export const modalDataID = state => state.id
export const modalData = state => state.data
export const modalSize = state => state.size
