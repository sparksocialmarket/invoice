export const getSelectedCompany = (state) => state.selectedCompany
export const getCompanies = (state) => state.companies
