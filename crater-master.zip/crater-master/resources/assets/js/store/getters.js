export const isAppLoaded = (state) => state.isAppLoaded
